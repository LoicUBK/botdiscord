# gmail-to-discord
Modified Google Apps Script to send selected gmail messages to Discord through a Discord webhook.
Just for personal purposes.
